package Model;

public class Event {
    private String id;
    private String name;
    private String[] candidates;
}
