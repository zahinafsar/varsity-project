package Model;

public class Vote {
    private String id;
    private Candidate candidateId;
    private Voter voterId;
    private Event eventId;
}
