package Model;

public class Voter extends User {
    private int voterId;

    public Voter(String _id, String _name, String _image, String _phone) {
        super(_id, _name, _image, _phone);
        this.voterId = (int) ((Math.random() * 9000) + 1000);
    }

    public int getVoterId() {
        return voterId;
    }
}
