package Database;

import Model.Candidate;

public class CandidateDB {
    public static Candidate users[] = new Candidate[100];
    public static int userCount = 0;
    public static int id = 1;

    public static void addCandidate(Candidate user) {
        for (int i = 0; i < users.length; i++) {
            if (users[i] == null) {
                users[i] = user;
                userCount++;
                id++;
                break;
            }
        }
    }

    public static String getNextId() {
        return String.valueOf(id);
    }

    public static void updateCandidate(String id, String name, String phone, String symbol) {
        for (int i = 0; i < users.length; i++) {
            if (users[i].getId().equals(id)) {
                users[i].setName(name);
                users[i].setPhone(phone);
                users[i].setImage(symbol);
                break;
            }
        }
    }

    public static void deleteCandidate(String id) {
        for (int i = 0; i < users.length; i++) {
            if (users[i].getId().equals(id)) {
                users[i] = null;
                userCount--;
                for (int j = i; j < users.length - 1; j++) {
                    users[j] = users[j + 1];
                }
                break;
            }
        }
    }
}
