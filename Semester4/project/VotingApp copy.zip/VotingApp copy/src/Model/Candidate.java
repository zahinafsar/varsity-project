package Model;

public class Candidate extends User {
    public Candidate(String id, String name, String image, String phone) {
        super(id, name, image, phone);
    }
}
