package network;

public interface IPAddressConverter {
    String convert(String input);
}
