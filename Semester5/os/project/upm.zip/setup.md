sudo -s
chmod +x ./setup.sh
./setup.sh